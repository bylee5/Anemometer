<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-Type" content="text/html; charset=utf-8" />
<title>Tmon DBA Board</title>
</head>
<body>

<?php
header("Content-Type: text/html; charset=UTF-8");

include "../mgm/conn/db_conn.php";

$updateConnect = mysqli_connect($monitorHost,$monitorUser,$monitorPswd,$monitorDb,$monitorPort);

if (mysqli_connect_errno($updateConnect)) {

	printf("페이지에 문제가 있습니다. 관리자에게 문의해주세요. ERROR_CODE=1001", mysqli_connect_error($updateConnect));
	mysqli_close($updateConnect);
	exit;

} else {

	mysqli_query ($updateConnect, "SET NAMES UTF8");

}

$insert_board_content = addslashes($_REQUEST['board_content']);

IF($_REQUEST['board_seqno']) {
	$dbUpdateSQL = "UPDATE tmon_dba_board SET board_content = '".$insert_board_content."' WHERE tmon_dba_board_seqno = ".$_REQUEST['board_seqno'];
	$dbUpdate = mysqli_query($updateConnect,$dbUpdateSQL);
} ELSE {
	echo "<script type='text/javascript'>alert('잘못된 접근입니다. 관리자에게 문의해주세요. ERROR_CODE=1003');</script>";
	mysqli_close($updateConnect);
	header('Location:tmon_dba_board.php');
}

$dbUpdateQuery = mysqli_query($updateConnect,$dbUpdateSQL);

if ($dbUpdate) {

	echo "<script type='text/javascript'>alert('업데이트 완료');</script>";
	mysqli_close($updateConnect);
	header('Location:tmon_dba_board.php?board_seqno='.$_REQUEST['board_seqno']);

} else {}

	echo "<script type='text/javascript'>alert('오류가 발생하였습니다. 관리자에게 문의해주세요. ERROR_CODE=1004');</script>";
	mysqli_close($updateConnect);
	header('Location:tmon_dba_board.php?board_seqno='.$_REQUEST['board_seqno']);

?>
</body>