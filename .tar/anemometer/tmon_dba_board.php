<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-Type" content="text/html; charset=utf-8" />
<title>Tmon DBA Board</title>

<style type = "text/css">
body {font-size:12px;font-family:돋움,dotum,arial;text-align:center;margin:20px auto;height:100%;overflow-x:hidden;}
</style>

<!--link rel="stylesheet" href="css/sample.css" type="text/css"-->

</head>
<body>


<?
header("Content-Type: text/html; charset=UTF-8");

include "../mgm/conn/db_conn.php";

$monitorConnect = mysqli_connect($monitorHost,$monitorUser,$monitorPswd,$monitorDb,$monitorPort);

if (mysqli_connect_errno($monitorConnect)) {

	printf("페이지에 문제가 있습니다. 관리자에게 문의해주세요. ERROR_CODE=1001", mysqli_connect_error($monitorConnect));
	mysqli_close($monitorConnect);
	exit;

} else {

	mysqli_query ($monitorConnect, "SET NAMES UTF8");

}

IF($_REQUEST['board_seqno']) {
	$dbSelectSQL = "select * from tmon_dba_board where tmon_dba_board_seqno = ".$_REQUEST['board_seqno'];
} ELSE {
	$dbSelectSQL = "select * from tmon_dba_board order by 1 desc limit 0,1";
}


$dbSelectQuery = mysqli_query($monitorConnect,$dbSelectSQL);

if (!$dbSelectQuery) {

	printf("페이지에 문제가 있습니다. 관리자에게 문의해주세요. ERROR_CODE=1002", mysqli_error($dbSelectQuery));
	mysqli_close($monitorConnect);
	exit;

} else {}

if (mysqli_num_rows($dbSelectQuery) == 0) {

	$dbInsertSQL = "INSERT INTO tmon_dba_board () VALUES ();";
	$dbInsertQuery = mysqli_query($monitorConnect,$dbInsertSQL);
	mysqli_close($monitorConnect);
	header('Location:tmon_dba_board.php');

} else {
	$dbSelectResult = mysqli_fetch_array($dbSelectQuery);
	$board_seqno	= $dbSelectResult[0];
	$board_content	= $dbSelectResult[2];
?>
<form action="tmon_dba_board_update.php" method="POST" name="updateform">
<div style="">
<textarea name="board_content" rows="30" cols="100" style="font-size:12px;"><?=$board_content?></textarea>
<input type="hidden" id="board_seqno" name="board_seqno" value="<?=$board_seqno?>" />
</div>
<div style="width:400px;margin:20px auto;text-align:center;">
<a href="./tmon_dba_board.php?board_seqno=<?=$board_seqno-4?>"><P style="width:30px;padding:0;margin:0 auto;font-weight:bold;font-size:16px;cursor:pointer;float:left;text-align:center;"><-</P></a>
<P style="width:100px;padding:0;margin:0px 120px 120px;font-weight:bold;font-size:16px;cursor:pointer;float:left;text-align:center;"><input type="submit" name="update" value="UPDATE"/></P>
<a href="./tmon_dba_board.php?board_seqno=<?=$board_seqno+4?>"><P style="width:30px;padding:0;margin:0 auto;font-weight:bold;font-size:16px;cursor:pointer;float:left;text-align:center;">-></P></a>
</div>
</form>
<?

}
mysqli_close($monitorConnect);

?>
</body>
</html>