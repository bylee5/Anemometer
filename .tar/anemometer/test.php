<?php
print 'TEST';
phpinfo();
?>
