<?php

print_r($columns);
print_r($result);

?>