<?php

print json_encode(array( 'columns' => $columns, 'result' => $result ));

?>